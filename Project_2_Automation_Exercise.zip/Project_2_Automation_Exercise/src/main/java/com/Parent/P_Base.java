package com.Parent;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class P_Base {
	public static WebDriver driver;
	public static Properties prop;

	public void initialization() {
		readPropertyFile();
		// how to read the browser variable?
		String browser = prop.getProperty("browser");

		if (browser.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("ie")) {
			driver = new InternetExplorerDriver();
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(prop.getProperty("url"));
	Screenshot.CaptureScreenshot("loginpage");
//		Screenshot.captureScreenshot("loginpage");

	}

	public void tearDown() {
		//driver.quit();
		driver.close();

	}

	public void readPropertyFile() {
		prop = new Properties();
		String propFilePath = "./src/main/java/com/config/config.properties";
		FileInputStream fis;
		try {
			fis = new FileInputStream(propFilePath);
			prop.load(fis);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public boolean verify_homePagePresent() {
		By home=By.xpath("//a[normalize-space()='Home']");
		return driver.findElement(home).isDisplayed();
	}
	


	
}
