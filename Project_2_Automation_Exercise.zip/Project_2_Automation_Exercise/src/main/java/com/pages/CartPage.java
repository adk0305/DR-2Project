package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.Parent.P_Base;

public class CartPage extends P_Base {
	
	
	By cart = By.xpath("//body[1]/header[1]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[3]/a[1]");
	By carttextpresent = By.xpath("//h2[normalize-space()='Subscription']");
	By mail= By.id("susbscribe_email");
	By arrow = By.xpath("//i[@class='fa fa-arrow-circle-o-right']");
	
	
	
	
	public void TC11_Cart() {
		
		driver.findElement(cart).click();
		
	}
	public boolean VerifySubscriptionText() {
		return driver.findElement(carttextpresent).isDisplayed();
	}

	public void EnterEmail() {
		driver.findElement(mail).sendKeys(prop.getProperty("subEmail"));
		

		driver.findElement(arrow).click();
		
	      	
	}
	public boolean VerifySuccessfullySbscribed() {
		WebElement subscrptn=driver.findElement(By.xpath("//h2[normalize-space()='You have been successfully subscribed!']"));;
		return subscrptn.isDisplayed();
		
	}
	
		
	}


