package com.pages;

import org.openqa.selenium.By;

import com.Parent.P_Base;

public class RemoveProductPage extends P_Base {
	
	By cartpage = By.xpath("//li[@class='active']");
	By Xbutton = By.xpath("//i[@class='fa fa-times']");
	By CartEmpty = By.xpath("//b[normalize-space()='Cart is empty!']");
	
	
	
	public boolean TC17_verifyCartPageVisible() {
		return driver.findElement(cartpage).isDisplayed();
	}
	public void ClickonXbutton() {
		driver.findElement(Xbutton).click();
	}
	public boolean VerifyCartisEmpty() {
		return driver.findElement(CartEmpty).isDisplayed();
		
	}

}
