package com.pages;

import java.time.Duration;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import com.Parent.P_Base;

public class SearchProductPage extends P_Base{
	
	By bluetop = By.xpath("//a[normalize-space()='Blue Top']");
	By wintertop = By.xpath("//a[normalize-space()='Winter Top']");
	By VerifyReview = By.xpath("//a[normalize-space()='Write Your Review']");
	By Name = By.xpath("//input[@id='name']");
	By mail = By.id("email");
	By review = By.xpath("//textarea[@id='review']");
	By submit = By.xpath("//button[@id='button-review']");
	
	
	public void TC20_Add_items_to_cart() {
	//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 300);
		
		driver.findElement(bluetop).click();
		driver.findElement(wintertop).click();
		
	}
	
	public boolean TC21_Add_Review() {
		return driver.findElement(VerifyReview).isDisplayed();
			
	}
	public void Top() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 500);
		driver.findElement(bluetop).click();
		
	}
	public void Enter_name() {
		Actions act = new Actions(driver);
		act.scrollByAmount(0, 300);
   driver.findElement(Name).sendKeys(prop.getProperty("RName"));
   driver.findElement(mail).sendKeys(prop.getProperty("Rmail"));
   driver.findElement(review).sendKeys(prop.getProperty("Review"));
   driver.findElement(submit).click();

	}
	
	
		
		
		
		
		
	


}
