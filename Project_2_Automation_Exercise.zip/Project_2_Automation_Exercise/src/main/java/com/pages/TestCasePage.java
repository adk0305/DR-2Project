package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.Parent.P_Base;

public class TestCasePage extends P_Base {
	public void TC7_TestCase() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement TC= driver.findElement(By.xpath("//a[contains(text(),'Test Cases')]"));
	TC.click();		
	}
	
	public boolean verifyusernavigatetoTC() {
		WebElement navigate= driver.findElement(By.xpath("//b[normalize-space()='Test Cases']"));
		return navigate.isDisplayed();
		
	}


}
