package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.BrandPage;
import com.pages.ProductPage;

public class BrandPageTest {
	
	BrandPage bp;
	ProductPage pp;
	
	@BeforeMethod
	public void browserSetup() {
		bp=new BrandPage();
		pp = new ProductPage();
		bp.initialization();
		
	}
	
	@Test(priority = 12)
	public void TC19_Brand() {
		pp.TC9_Products();
		bp.TC19_Brand_Present();
		Assert.assertTrue(bp.TC19_Brand_Present());
		bp.click_on_brand();
		Assert.assertTrue(bp.Verify_brand_product());
		bp.click_another_brand();
		Assert.assertTrue(bp.Verify_another_brand());
	}
	@AfterMethod
	public void closeSetup() {
		bp.tearDown();
	}	

}
