package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.CartPage;
import com.pages.ProductPage;
import com.pages.RemoveProductPage;
import com.pages.productQuantityPage;

public class RemoveProductPageTest {
	RemoveProductPage rpp;
	 ProductPage pg;
	 productQuantityPage pqp;
	 CartPage cp;
	
	@BeforeMethod
	public void browserSetup() {
		rpp = new RemoveProductPage();
		pg = new ProductPage();
		cp = new CartPage();
		pqp = new productQuantityPage();
		rpp.initialization();
		
	}
	@Test
	public void TC17_RemoveProducts() {
		pg.TC12_HoverOnProductaddtocart();
		pqp.viewcart();
		cp.TC11_Cart();
		Assert.assertTrue(rpp.TC17_verifyCartPageVisible());
		rpp.ClickonXbutton();
		Assert.assertTrue(rpp.VerifyCartisEmpty());

	}
	@AfterMethod
	public void closeSetup() {
		rpp.tearDown();
	}	
	}


