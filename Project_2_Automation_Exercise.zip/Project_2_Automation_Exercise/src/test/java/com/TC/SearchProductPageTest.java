package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.CartPage;
import com.pages.LoginPage;
import com.pages.ProductPage;
import com.pages.SearchProductPage;

public class SearchProductPageTest {
	SearchProductPage spp;
	ProductPage pp;
	LoginPage lp;
	CartPage cp;
	
	
	@BeforeMethod
	public void browserSetup() {
		spp = new SearchProductPage();
		pp=new ProductPage();
		cp = new CartPage();
		lp = new LoginPage();
		
		spp.initialization();
		
	}
	
	@Test(priority = 13)
	public void TC20_() {
		pp.TC9_Products();
		pp.VerifyNavigateToAllProducts();
		pp.prdctnameininput();
		pp.ClickOnSearchButton();
		spp.TC20_Add_items_to_cart();
		pp.TC8_ViewProduct();
		lp.TC2_LoginDetails();
		cp.TC11_Cart();
	}
	@Test
	public void TC21_Review() {
		pp.TC9_Products();
		pp.VerifyNavigateToAllProducts();
		spp.Top();
		spp.TC20_Add_items_to_cart();
		Assert.assertTrue(spp.TC21_Add_Review());
		spp.Enter_name();
		
	}
	@AfterMethod
	public void closeSetup() {
		spp.tearDown();
	}
}
