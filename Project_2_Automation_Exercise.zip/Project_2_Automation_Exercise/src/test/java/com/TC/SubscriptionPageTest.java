package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.SubscriptionPage;

public class SubscriptionPageTest {

	SubscriptionPage sp;
	@BeforeMethod
	public void browserSetup() {
		sp = new SubscriptionPage();
		sp.initialization();	
	}
	
	
	@Test(priority = 7)
	public void TC10_Subscriptionpage() {
		sp.TC10_ScrollToFooter();
		Assert.assertTrue(sp.VerifySubscriptionText());
		sp.EnterEmail();
		Assert.assertTrue(sp.VerifySuccessfullySbscribed());
	}
	@AfterMethod
	public void closeSetup() {
		sp.tearDown();
	}	
}
