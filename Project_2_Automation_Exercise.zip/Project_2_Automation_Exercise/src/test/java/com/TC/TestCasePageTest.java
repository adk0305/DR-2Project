package com.TC;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.TestCasePage;

public class TestCasePageTest {
	
	TestCasePage tcp;
	
	@BeforeMethod
	public void browserSetup() {
		tcp = new TestCasePage();
		tcp.initialization();
	}	
	@Test(priority = 4)
	public void clickTCbutton() {
		tcp.TC7_TestCase();
		Assert.assertTrue(tcp.verifyusernavigatetoTC());
	}
	@AfterMethod
	public void closeSetup() {
		tcp.tearDown();
	}		
	}
	


