package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.ProductPage;
import com.pages.SignupPage;
import com.pages.TestCases22and23Page;
import com.pages.placeorderPage;
import com.pages.productQuantityPage;
import com.pages.scrollupscrolldownPage;


public class TestCases22and23PageTest {
	
	TestCases22and23Page t22t23;
	ProductPage prd;
	SignupPage sp;
    productQuantityPage pqp;
    placeorderPage po;
    
	@BeforeMethod
	public void browserSetup() {
		t22t23 = new TestCases22and23Page();
		sp     = new SignupPage();	
		prd    = new ProductPage();
		pqp    = new productQuantityPage();
		po     = new placeorderPage();
        t22t23.initialization();
		
	}
	@Test
	public void RecommendedItems() {
//		sc.TC26_ScrolldowntoBottom();
		
		t22t23.TC22_scrolldown();
		t22t23.RItems();
		t22t23.shirt();
		t22t23.viewcart();
		sp.TC1_signup_login();
		Assert.assertTrue(sp.verify_homePagePresent());
        sp.CA();
        Assert.assertTrue(sp.verifysignupdetails());
        sp.fillsignupdetails();
        sp.filladdressinfo();      
        sp.click_create_account();	
        Assert.assertTrue(sp.verifyacc_created());
        Assert.assertTrue(sp.verifyloggedinuser());
		prd.TC12_HoverOnProductaddtocart();	
	    pqp.viewcart(); 
		po.ProceedtoCheckout();
		t22t23.deleteacc();
		t22t23.verify_delacc();
	}
	@Test
	public void TC24_All() {
		t22t23.TC22_scrolldown();
		t22t23.RItems();
		t22t23.shirt();
		t22t23.viewcart();		
		sp.TC1_signup_login();
		Assert.assertTrue(sp.verify_homePagePresent());
        sp.CA();
        Assert.assertTrue(sp.verifysignupdetails());
        sp.fillsignupdetails();
        sp.filladdressinfo();      
        sp.click_create_account();	
        Assert.assertTrue(sp.verifyacc_created());
        Assert.assertTrue(sp.verifyloggedinuser());
		prd.TC12_HoverOnProductaddtocart();	
	    pqp.viewcart(); 
		po.ProceedtoCheckout();
		t22t23.deleteacc();
		t22t23.verify_delacc();	
	}
	
	@AfterMethod
	public void closeSetup() {
		t22t23.tearDown();
	}	
	
	}


