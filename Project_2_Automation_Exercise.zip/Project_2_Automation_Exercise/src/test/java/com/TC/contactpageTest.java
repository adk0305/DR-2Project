package com.TC;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.contactpage;

public class contactpageTest {
	contactpage cp;
	
	  
	@BeforeMethod
	public void browserSetup() {
	cp = new contactpage();
	cp.initialization();
	}
	
	@Test(priority = 3)
	public void contactus() {
		cp.TC6_clickoncontact();
		Assert.assertTrue(cp.verifygetintouch());
		cp.fillTheDtails();
        cp.UploadFile();
        cp.verifysuccess();
        cp.scrollingdown();
	}
	@AfterMethod
	public void closeSetup() {
		cp.tearDown();
	}	
		
	}


