package com.TC;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.pages.paymentPage;

public class paymentPageTest {
	paymentPage pg;
	
	@BeforeMethod
	public void browserSetup() {
		pg = new paymentPage();
		pg.initialization();
	}
	@AfterMethod
	public void closeSetup() {
		pg.tearDown();
	}
}
